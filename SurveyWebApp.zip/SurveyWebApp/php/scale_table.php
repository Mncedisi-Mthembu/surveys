<div class="row">
    <table class="table table-bordered">
        <thead class="table-secondary bold-border">
            <tr>
                <td scope="col" class="text-center"></td>
                <td scope="col" class="text-center">Strongly Agree</td>
                <td scope="col" class="text-center">Agree</td>
                <td scope="col" class="text-center">Neutral</td>
                <td scope="col" class="text-center">Disagree</td>
                <td scope="col" class="text-center">Strongly Disagree</td>
            </tr>
        </thead>
        <tbody class="blue-border">
            <tr>
                <td scope="row">I like to watch movie.</td>
                <td class="text-center"><input type="radio" name="watchMovie" value="1"></td>
                <td class="text-center"><input type="radio" name="watchMovie" value="2"></td>
                <td class="text-center"><input type="radio" name="watchMovie" value="3"></td>
                <td class="text-center"><input type="radio" name="watchMovie" value="4"></td>
                <td class="text-center"><input type="radio" name="watchMovie" value="5"></td>
            </tr>

            <tr>
                <td scope="row">I like to listen to radio.</td>
                <td class="text-center"><input type="radio" name="listenRadio" value="1"></td>
                <td class="text-center"><input type="radio" name="listenRadio" value="2"></td>
                <td class="text-center"><input type="radio" name="listenRadio" value="3"></td>
                <td class="text-center"><input type="radio" name="listenRadio" value="4"></td>
                <td class="text-center"><input type="radio" name="listenRadio" value="5"></td>
            </tr>

            <tr>
                <td scope="row">I like to eat out.</td>
                <td class="text-center"><input type="radio" name="eatOut" value="1"></td>
                <td class="text-center"><input type="radio" name="eatOut" value="2"></td>
                <td class="text-center"><input type="radio" name="eatOut" value="3"></td>
                <td class="text-center"><input type="radio" name="eatOut" value="4"></td>
                <td class="text-center"><input type="radio" name="eatOut" value="5"></td>
            </tr>

            <tr>
                <td scope="row">I like to watch TV.</td>
                <td class="text-center"><input type="radio" name="watchTV" value="1"></td>
                <td class="text-center"><input type="radio" name="watchTV" value="2"></td>
                <td class="text-center"><input type="radio" name="watchTV" value="3"></td>
                <td class="text-center"><input type="radio" name="watchTV" value="4"></td>
                <td class="text-center"><input type="radio" name="watchTV" value="5"></td>
            </tr>
        </tbody>
    </table>
</div>