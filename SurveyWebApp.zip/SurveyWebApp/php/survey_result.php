<!DOCTYPE html>
<html lang="en">
    <?php include '../php/header.php'; ?>
    <style><?php include '../css/style.css'; ?>
    </style>
    <body>
        <div class="container">
            <?php include '../php/navbar.php'; ?> 
            <h1>Survey Result</h1>
            <br>
            <?php
            try {
                include '../php/survey_result_file.php';
                ?>
                <div class="row justify-content-center text-center">
                    <div class="col-6 col-sm-4 text-start">Total number of surveys:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $totalNumSurvery ? "$totalNumSurvery surveys" : "No surveys"; ?></div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">Average Age:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $avg; ?> average age</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">Oldest person who participated in survey:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $max; ?> max age</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">Youngest person who participated in survey:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $min; ?> min age</div>

                    <div class="w-100 mb-2"></div>
                    <div class="w-100 mb-2"></div>
                    <div class="w-100 mb-2"></div>
                    <div class="w-100 mb-2"></div>

                    <div class="col-6 col-sm-4 text-start">Percentage of people who like Pizza:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $pizzaPerc; ?>% Pizza</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">Percentage of people who like Pasta:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $pastaPerc; ?>% Pasta</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">Percentage of people who like Pap and Wors:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $papAndWorsPerc; ?>% Pap and Wors</div>

                    <div class="w-100 mb-2"></div>
                    <div class="w-100 mb-2"></div>
                    <div class="w-100 mb-2"></div>
                    <div class="w-100 mb-2"></div>

                    <div class="col-6 col-sm-4 text-start">People who like to watch movies:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $watchMovieAvg; ?> average of rating</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">People who like to listen to radio:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $listenRadioAvg; ?> average of rating</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">People who like to eat out:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $eatOutAvg; ?> average of rating</div>

                    <div class="w-100 mb-2"></div>
                    <div class="col-6 col-sm-4 text-start">People who like to watch TV:</div>
                    <div class="col-6 col-sm-4 text-end"><?php echo $watchTVAvg; ?> average of rating</div>
                </div>
                <?php
            } catch (DivisionByZeroError $e) {
                echo "<script>alert('⚠️ No Surveys Available!');window.location.href='index.php';</script>";
                exit();
            } catch (Exception $e) {
                echo "<script>alert('❌ Something went wrong try agin');window.location.href='index.php';</script>";
                exit();
            }
            ?>
        </div>
    </body>
</html>

