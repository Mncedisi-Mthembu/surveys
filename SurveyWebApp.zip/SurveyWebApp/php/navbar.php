<div class="d-flex justify-content-between align-items-start">
    <label class="fw-bold mt-2">_Surveys</label>
    <ul class="nav nav-tabs card-header-tabs">
        <li class="nav-item">
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="index.php">FILL OUT SURVEYS</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'survey_result.php' ? 'active' : '' ?>" href="survey_result.php">VIEW SURVEY RESULT</a>
        </li>
    </ul>
</div>


