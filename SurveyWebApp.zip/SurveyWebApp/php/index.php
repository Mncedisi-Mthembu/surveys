<!DOCTYPE html>
<html lang="en">
    <?php include './header.php'; ?>
    <style><?php include '../css/style.css'; ?></style>
    <body>
        <div class="container">
            <?php include './navbar.php'; ?> <br><br>
            <form id="formValidation" action="process_data_file.php" method="Post" onsubmit="return">
                <div class="row">
                    <div class="row">
                        <div class="col-3">
                            <label>Personal Details:</label>
                        </div>
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="fullNames" class="form-label">Full Names</label>
                                <input type="text" class="form-control" id="fullNames" aria-describedby="fullNames" name="fullNames" >
                                <span id="fullNames-error" class="error-message" ></span><!-- Error message inside the field -->
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" aria-describedby="email" name="email" >
                                <span id="email-error" class="error-message"></span><!-- Error message inside the field -->
                            </div>
                            <div class="mb-3">
                                <label for="dateOfBirth" class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" id="dateOfBirth" aria-describedby="dateOfBirth" name="dateOfBirth">
                                <input type="hidden" class="form-control" id="age" aria-describedby="age" name="age">
                                <span id="dateOfBirth-error" class="error-message"></span><!-- Error message inside the field -->
                            </div>
                            <div class="mb-3">
                                <label for="contactNumber" class="form-label">Contact Number</label>
                                <input type="tel" class="form-control" id="contactNumber" name="contactNumber">
                                <span id="contactNumber-error" class="error-message"></span><!-- Error message inside the field -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <label>What is your favorite food?</label>
                        </div>
                        <div class="col-5">
                            <div class="mb-3">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="pizza" name="food[]" value="Pizza">
                                    <label class="form-check-label" for="pizza">Pizza</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="pasta" name="food[]" value="Pasta">
                                    <label class="form-check-label" for="pasta">Pasta</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="papAndWors" name="food[]" value="Pap and Wors">
                                    <label class="form-check-label" for="papAndWors">Pap and Wors</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="other" name="food[]" value="Other">
                                    <label class="form-check-label" for="other">Other</label>
                                </div>
                            </div>
                            <span id="food-error" class="error-message"></span>
                        </div>
                    </div>
                </div>
                <br><br>
                <label>Please rate your level of agreement on a scale from 1 to 5, with 1 being "storng agree" and 5 being "strong disagree."</label>
                <br><br>
                <?php include './scale_table.php'; ?>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <?php include './footer.php'; ?>
    </body>
</html>
