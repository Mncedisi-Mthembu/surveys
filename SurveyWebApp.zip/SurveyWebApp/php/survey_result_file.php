<?php

include '../database/config.php';
//Declaretion

//Total number of surveys
$totalNumSurvery = $conn->query("SELECT COUNT(*) AS total FROM person")->fetch_assoc()['total'];

//Survey average age 
$resultAvg = $conn->query("SELECT AVG(age) AS average_age FROM person");
$avg = number_format($resultAvg->fetch_assoc()['average_age'], 1);

//Oldest survey 
$resultMax = $conn->query("SELECT MAX(age) AS max_age FROM person");
$max = $resultMax->fetch_assoc()['max_age'];

//Youngest survey
$resultMin = $conn->query("SELECT MIN(age) AS min_age FROM person");
$min = $resultMin->fetch_assoc()['min_age'];

//Count number of pizza
$pizzaCount = $conn->query("SELECT COUNT(*) AS count FROM food WHERE foodname = 'Pizza'")->fetch_assoc()['count'];

//Calculate pizza percentage
$pizzaPerc = number_format((($pizzaCount / $totalNumSurvery) * 100),1);

//Count number of Pasta
$pastaCount = $conn->query("SELECT COUNT(*) AS count FROM food WHERE foodname = 'Pasta'")->fetch_assoc()['count'];

//Calculate pasta percentage
$pastaPerc = number_format((($pastaCount / $totalNumSurvery) * 100),1);

//Count number of pap and wors
$papAndWorsCount = $conn->query("SELECT COUNT(*) AS count FROM food WHERE foodname = 'Pap and Wors'")->fetch_assoc()['count'];

//Calculate pap and wors percentage
$papAndWorsPerc = number_format((($papAndWorsCount / $totalNumSurvery) * 100),1);

//Survey average age 
$resultWatchMovieAvg = $conn->query("SELECT AVG(watch_movie) AS watch_movie FROM scale");
$watchMovieAvg = number_format($resultWatchMovieAvg->fetch_assoc()['watch_movie'], 1);

//Survey average age 
$resultListenRadioAvg = $conn->query("SELECT AVG(listen_radio) AS listen_radio FROM scale");
$listenRadioAvg = number_format($resultListenRadioAvg->fetch_assoc()['listen_radio'], 1);

//Survey average age 
$resultEatOutAvg = $conn->query("SELECT AVG(eat_out) AS eat_out FROM scale");
$eatOutAvg = number_format($resultEatOutAvg->fetch_assoc()['eat_out'], 1);

//Survey average age 
$resultWatchTVAvg = $conn->query("SELECT AVG(watch_tv) AS watch_tv FROM scale");
$watchTVAvg = number_format($resultWatchTVAvg->fetch_assoc()['watch_tv'], 1);

