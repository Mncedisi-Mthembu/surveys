<?php
include '../database/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //retrieve form data
    $fullNames = $_POST['fullNames'];
    $email = $_POST['email'];
    $dateOfBirth = $_POST['dateOfBirth'];
    $contactNumber = $_POST['contactNumber'];
    $age = $_POST['age'];

    //array
    $foodnames = $_POST['food'];

    $watchMovie = $_POST['watchMovie'];
    $listenRadio = $_POST['listenRadio'];
    $eatOut = $_POST['eatOut'];
    $watchTV = $_POST['watchTV'];

    // Prepare the statement
    $stmt = $conn->prepare("SELECT * FROM person WHERE email = ?");
    $stmt->bind_param("s", $email); // "s" means the parameter is a string
    // Execute the query
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "<script>alert('🔁 Person with this email is already existing');window.location.href='../index.php';</script>";
        exit();
    }

    $isPersonStored = FALSE;
    $isFoodStored = FALSE;
    $isScaleStored = FALSE;

    // Prepare the SQL statement
    $stmtp = $conn->prepare("INSERT INTO person (fullname, email, dob, age, contactnumber) VALUES (?, ?, ?, ?, ?)");

    // Bind the parameters (s = string, i = integer)
    $stmtp->bind_param("sssis", $fullNames, $email, $dateOfBirth, $age, $contactNumber);

    // Execute and check for success
    if ($stmtp->execute()) {
        $isPersonStored = TRUE;
    }

    $stmtf = $conn->prepare("INSERT INTO food (person_email, foodname) VALUES (?, ?)");

    foreach ($foodnames as $foodname) {
        $stmtf->bind_param("ss", $email, $foodname);
        if ($stmtf->execute()) {
            $isFoodStored = TRUE;
        } else {
            $isFoodStored = FALSE;
            exit();
        }
    }

    $stmts = $conn->prepare("INSERT INTO scale (person_email, watch_movie, listen_radio, eat_out, watch_tv) VALUES (?, ?, ?, ?, ?)");
    $stmts->bind_param("siiii", $email, $watchMovie, $listenRadio, $eatOut, $watchTV);

    if ($stmts->execute()) {
        $isScaleStored = TRUE;
    }
    
    if($isPersonStored && $isFoodStored && $isScaleStored){
        echo "<script>alert('✅ The data is stored succesfully');window.location.href='../index.php';</script>";
        exit();
    }else{
        echo "<script>alert('❌ Something went wrong try again!');window.location.href='../index.php';</script>";
        exit();
    }
}

