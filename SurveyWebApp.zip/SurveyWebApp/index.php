<?php
// Redirect after update
header("Location: ./php/index.php");
exit();
?>
