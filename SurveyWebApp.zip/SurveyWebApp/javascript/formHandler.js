$(document).ready(function () {
    $('#formValidation').submit(function (event) {
        event.preventDefault(); // Prevent default form submission

        if (isFormValidation()) {
            this.submit(); // Proceed with submission if validation passes
        }
    });
});

function isFormValidation() {
    let fullNames = $('#fullNames').val();
    let email = $('#email').val();
    let dateOfBirth = new Date($('#dateOfBirth').val());
    let contactNumber = $('#contactNumber').val();
    let age = $('#age').val();

    let pizza = $('#pizza').is(':checked');
    let pasta = $('#pasta').is(':checked');
    let papAndWors = $('#papAndWors').is(':checked');
    let other = $('#other').is(':checked');
    let isSelectedWatchMovie = $('input[name="watchMovie"]:checked').length > 0;
    let isSelectedListenRadio = $('input[name="listenRadio"]:checked').length > 0;
    let isSelectedEatOut = $('input[name="eatOut"]:checked').length > 0;
    let isSelectedWatchTV = $('input[name="watchTV"]:checked').length > 0;

    // Reset previous error messages
    $('#email-error').hide();
    $('#fullNames-error').hide();
    $('#dateOfBirth-error').hide();
    $('#contactNumber-error').hide();
    $('#food-error').hide();

    let isValid = true;

    //Validate radio
    if (!isSelectedWatchMovie || !isSelectedListenRadio || !isSelectedEatOut || !isSelectedWatchTV) {
        alert("❓Please rate all the questions");
        isValid = false;
    }

    //Validate checkbox food
    if (!pizza && !pasta && !papAndWors && !other) {
        $('#food-error').text('❓ Please select food.').show();
        isValid = false;
    }

    //Validate contact number
    if (!contactNumber) {
        $('#contactNumber-error').text('❓ Contact number is required.').show();
        isValid = false;
    } else if (!/^0\d{9}$/.test(contactNumber)) {
        $('#contactNumber-error').text('❌ .Contact number must be 10 digits starting with 0, e.g format[0123456789]').show();
        isValid = false;
    }

    const currentYear = new Date().getFullYear();
    const birthYear = dateOfBirth.getFullYear();

    //Calculate age
    age = currentYear - birthYear;
    document.getElementById('age').value = age;

    //Validate date of birth
    if (!$('#dateOfBirth').val()) {
        $('#dateOfBirth-error').text('❓ DoB is required.').show();
        isValid = false;
    } else if (birthYear >= currentYear) {
        $('#dateOfBirth-error').text('❌ Invalid date of birth: Birth year cannot be the current year or a future year.').show();
        isValid = false;
    }else if(age<5 || age>120){
        $('#dateOfBirth-error').text('❌ Age must be between[5-120]').show();
        isValid = false;
    }

    //Validate full names
    if (!fullNames) {
        $('#fullNames-error').text('❓ Full names are required.').show();
        isValid = false;
    } else if (!/^[A-Za-z\s]+$/.test(fullNames)) {
        $('#fullNames-error').text('❌ Full names must have only letters.').show();
        isValid = false;
    }

    // Validate email
    if (!email) {
        $('#email-error').text('❓ Email is required.').show();
        isValid = false;
    }

    return isValid;
}
;



